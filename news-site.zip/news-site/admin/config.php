<?php 
$conn=mysqli_connect("localhost","root","","news-site") or die("Connection Failed");
?>