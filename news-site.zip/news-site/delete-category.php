<?php 
include "config.php";
echo $cat_did=$_GET['cat_did'];
?>